#!/bin/bash
# Places a rich text link on the clipboard
# usage: rtflink.sh "Title of link" "URL to link to"
#
# This will paste *nothing* into applications that don't recognize rich text

echo "{\rtf1\ansi\ansicpg1252\cocoartf949\cocoasubrtf270
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural\pardirnatural
{\field{\*\fldinst{HYPERLINK \"$2\"}}{\fldrslt 
\f0\fs24 \cf0 $1}}}" | pbcopy -Prefer rtf